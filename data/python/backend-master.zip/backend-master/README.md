# Freenit Backend
![freenit badge](https://github.com/freenit-framework/backend/actions/workflows/pythonapp.yml/badge.svg)

[Documentation](https://freenit.org/backend/quickstart)

[Source](https://github.com/freenit-framework/backend)

Freenit is based on

* [FastAPI](https://fastapi.tiangolo.com/)
* [Ormar](https://github.com/collerek/ormar)
* [Svelte](https://svelte.dev)
