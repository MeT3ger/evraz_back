import freenit.api.auth
import freenit.api.role
import freenit.api.theme
import freenit.api.user

from .router import api


# TODO: Вынести в слой adapters/api