from freenit.auth import permissions

role_perms = permissions()
profile_perms = permissions()
user_perms = permissions()
theme_perms = permissions()
