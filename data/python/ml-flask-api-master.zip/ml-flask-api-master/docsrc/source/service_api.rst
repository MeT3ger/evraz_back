
Service
-------
.. automodule:: service
  :members:
  :undoc-members:
  :show-inheritance:
  :exclude-members: MODEL_TYPE, DEBUG, MODEL_NAME, ENVIRONMENT, SERVICE_START_TIMESTAMP, app, model
