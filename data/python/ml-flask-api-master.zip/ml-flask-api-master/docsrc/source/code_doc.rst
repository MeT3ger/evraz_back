Code Documentation
==================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   base_model
   sklearn_model
   service_api
