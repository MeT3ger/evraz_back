Base Model
~~~~~~~~~~
.. automodule:: python.model.base
  :members:
  :undoc-members:
  :show-inheritance:
  :exclude-members: SHAP_AVAILABLE, Task
