Scikit-learn Model
~~~~~~~~~~~~~~~~~~
.. automodule:: python.model.sklearn
  :members:
  :undoc-members:
  :show-inheritance:
