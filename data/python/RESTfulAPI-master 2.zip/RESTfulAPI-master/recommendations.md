#### Переидти от функционального подхода к объектно-ориентированному сиспользованием паттерна "Репозиторий" может улучшить структуру и поддерживаемость кода. 
#### Использовать dependency injection
#### Добавить аннотацию аргументов
#### Привести структуру проекта к стандартам
- **components/**
  - **backend/**
    - **application_name/**
      - **adapters/** 
        - **app_database/**
          - repositories.py
          - settings.py
        - **http_api/**
          - create_app.py
          - controllers.py
          - settings.py
      - **application/**
        - interfaces.py
        - service.py
      - **composites/**
        - **http_api.py** 
    - **tests/**
      
#### собрать проект в python пакет
