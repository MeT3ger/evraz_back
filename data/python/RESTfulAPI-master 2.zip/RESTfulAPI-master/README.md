# RESTfulAPI
flask-restful 实例。

以mongodb作为数据库。

