#!/usr/bin/env python
# encoding: utf-8

"""
    File name: default.py
    Function Des: ...
    ~~~~~~~~~~
    
    author: Jerry <cuteuy@gmail.com> <http://www.skyduy.com>
    
"""
# TODO: секреты передавать через переменные окружения
#  настройки хранить в settings и использовать BaseSettins из Pydantic

MONGODB_SETTINGS = {'DB': 'library'}  # 设置mongodb的数据库
PASSWORD_SECRET = 'secret_for_ensure_password_security'
TOKEN_SECRET = 'secret_for_ensure_token_security'
