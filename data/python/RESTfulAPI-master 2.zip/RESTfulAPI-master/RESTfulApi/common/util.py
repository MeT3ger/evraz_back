#!/usr/bin/env python
# encoding: utf-8

"""
    File name: util.py
    Function Des: ...
    ~~~~~~~~~~
    
    author: Jerry <cuteuy@gmail.com> <http://www.skyduy.com>
    
"""

# TODO: пустой модуль