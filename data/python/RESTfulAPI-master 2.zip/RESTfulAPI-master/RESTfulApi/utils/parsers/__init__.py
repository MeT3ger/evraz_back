#!/usr/bin/env python
# encoding: utf-8

"""
    File name: __init__.py.py
    Function Des: ...
    ~~~~~~~~~~
    
    author: Jerry <cuteuy@gmail.com> <http://www.skyduy.com>
    
"""
# TODO: Для ваоидации использовать Pydantic
# TODO: перенести в слой адаптер


from common import *
