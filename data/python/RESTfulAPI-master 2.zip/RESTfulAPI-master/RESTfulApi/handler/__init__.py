#!/usr/bin/env python
# encoding: utf-8

"""
    File name: __init__.py
    Function Des: ...
    ~~~~~~~~~~
    
    author: Jerry <cuteuy@gmail.com> <http://www.skyduy.com>
    
"""


# TODO: разделить проверку токенов и работу с БД
#  - проверка токенов осуществлять в контроллерах адаптера
#  - работа с БД осуществлять в репозиториях адаптера
#


