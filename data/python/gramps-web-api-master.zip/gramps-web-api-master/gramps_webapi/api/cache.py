"""Caching functions."""

from flask_caching import Cache

thumbnail_cache = Cache()
