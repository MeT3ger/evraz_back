from shared.serializers import PageSerializer


class OrderListSerializer(PageSerializer):
    resource_name = 'orders'

