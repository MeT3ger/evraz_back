from flask import Blueprint

blueprint = Blueprint('main', __name__)