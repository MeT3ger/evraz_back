import comments.views
import sys


sys.stdout.write('[+] Registering comment routes\n')

