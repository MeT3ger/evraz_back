import categories.views
import sys

sys.stdout.write('[+] Registering category routes\n')
