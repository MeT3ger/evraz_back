import products.views  # this will trigger the execution of that script which in turn register the routes
import sys

sys.stdout.write('[+] Registering product routes\n')
