import ecommerce_api.views
