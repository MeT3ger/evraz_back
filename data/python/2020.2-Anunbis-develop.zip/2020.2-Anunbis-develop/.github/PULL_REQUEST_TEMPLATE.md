<!--- Forneça um resumo geral das suas alterações no título acima -->
<!--- Caso não preenchido algum campo opcional, deletá-lo do Pull Request para maior transparência na mensagem. -->

## Descrição 
<!---Campo obrigatório -->
<!---Descrição concisa do que foi feito -->

## Resolve (Issues)
<!---Campo obrigatório -->
<!---Issues que foram resolvidas com o PR -->

## Como Isso Foi Testado (caso necessário)?
<!---Campo opcional -->
<!--- Por favor, descreva detalhadamente como você testou suas mudanças. -->
<!--- Inclua detalhes do seu ambiente de teste e os testes que você executou -->
<!--- para ver como a sua alteração afeta outras áreas do código, etc. -->

## Capturas de Tela (se apropriado):
<!---Campo opcional -->

## Tarefas gerais realizadas
<!---Campo obrigatório -->
* Tarefa 1
* Tarefa 2
