---
name: Bug report
about: Nos informe um bug para que possamos corrigir
title: "[BUG] "
labels: bug
assignees: ''

---

### Descrição do bug:
<!--Explicação clara do que ocorre no bug. -->

### Para reproduzi-lo:
<!--Passos para encontrar o bug-->
1. Vá para'...'
2. Click em '....'
3. Desça até '....'
4. Veja o erro.

### Captura de Tela:


### Sistema:
 - OS: [e.g. iOS]
 - Browser [e.g. chrome, safari]
 - Versão[e.g. 22]

### Informações adicionais:
