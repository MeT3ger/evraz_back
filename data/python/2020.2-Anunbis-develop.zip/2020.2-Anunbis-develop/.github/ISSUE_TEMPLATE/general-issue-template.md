---
name: General Issue Template
about: Issues não relacionadas a bugs.
title: ''
labels: ''
assignees: ''

---

### Descrição:
<!-- Descrever de maneira clara e objetiva o propósito da issue. -->

### Tarefas:
<!-- Checklist de ações que devem ser realizadas. -->

- [ ]  

### Critérios de aceitação:
<!-- Descrever os requisitos necessários para que a issue possar ser finalizada. -->

- [ ]
