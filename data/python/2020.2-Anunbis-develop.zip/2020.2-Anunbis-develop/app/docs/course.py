course_list_get = {
    "summary": "This path is responsable for getting the list of courses.",
    "tags": ["Course's paths"],
    "description": "It doesn't require an authorization header or any value",
    "responses": {"200": {"description": "Success"}},
}
