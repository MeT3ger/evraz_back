authorization_header = {
    "in": "header",
    "name": "Authorization",
    "type": "string",
    "required": True,
    "default": "Bearer ",
}
