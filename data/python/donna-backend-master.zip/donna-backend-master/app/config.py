SQLALCHEMY_DATABASE_URI = 'sqlite:///data/office-data.db'
SQLALCHEMY_ECHO = False
SECRET_KEY = 'L0nd0n6rIdg3i5F@11ingD0wn'
