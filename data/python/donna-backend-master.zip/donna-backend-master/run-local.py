from app import myapp

myapp.debug = True
myapp.run(port=8090)
