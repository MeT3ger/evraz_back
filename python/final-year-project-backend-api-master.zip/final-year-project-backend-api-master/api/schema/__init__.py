from api.schema.students_schema import NewStudentSchema, EditMeSchema
from api.schema.auth_schema import StudentLoginSchema, LecturerLoginSchema, HODLoginSchema, AdminLoginSchema
from api.schema.lecturers_schema import NewLecturerSchema
from api.schema.hods_schema import NewHODSchema, EditHODSchema
from api.schema.admins_schema import NewAdminSchema
