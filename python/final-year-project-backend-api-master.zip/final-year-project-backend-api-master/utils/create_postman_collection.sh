#!/bin/sh

python3 postman.py > postman_collection
