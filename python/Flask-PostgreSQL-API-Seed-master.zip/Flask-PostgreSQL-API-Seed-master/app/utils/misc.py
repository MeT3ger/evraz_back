# TODO Перенести этот модуль в components/app/application/utils.py

import uuid


def make_code():
    return str(uuid.uuid4())
