

# TODO Перенести этот модуль в components/app/adapters/api/controllers/user.py

from datetime import datetime

from flask import g
from flask.ext import restful
from flask.ext.restful import reqparse, fields, marshal_with
from sqlalchemy.exc import IntegrityError


from app.users.mixins import SignupLoginMixin
from app.users.models import AppUser, PasswordReset

from app.utils.auth import auth_required, admin_required, generate_token
from app.utils.errors import EMAIL_IN_USE, CODE_NOT_VALID, BAD_CREDENTIALS

from app import db, bcrypt


user_fields = {
    'id': fields.Integer,
    'email': fields.String
}


class UserAPI(SignupLoginMixin, restful.Resource):

    @auth_required
    @marshal_with(user_fields)
    def get(self):
        return g.current_user

    # TODO судя по всему необходим декоратор @auth_required
    def post(self):
        args = self.req_parser.parse_args()

        user = AppUser(email=args['email'], password=args['password'])
        db.session.add(user)

        try:
            # TODO Не стоит управлять транзакцией внутри каждого обработчика
            #  запросов. Это приведет к дублированию кода. Эту функциональность
            #  можно вынести в декоратор либо в базовый класс контроллера
            #  запросов.
            db.session.commit()
        # TODO Следует применять централизованный обработчик ошибок
        except IntegrityError:
            return EMAIL_IN_USE

        return {
            'id': user.id,
            'token': generate_token(user)
        }, 201  # TODO Необходимо использовать код успешного завершения запроса
        #           по умолчанию централизованно, чтобы не указывать его каждый
        #           раз. Код ответа можно поместить в константы.


class AuthenticationAPI(SignupLoginMixin, restful.Resource):

    def post(self):
        args = self.req_parser.parse_args()

        # TODO Не стоит формировать объекты запросов в контроллерах. Для этого
        #  стоит использовать репозиторий. Хотя в новой архитектуре это
        #  допускается.
        user = db.session.query(AppUser).filter(AppUser.email==args['email']).first()
        # TODO Данную проверку можно поместить в класс пользователя, поскольку
        #  данные пользователей напрямую зависят от алгоритма хэширования.
        if user and bcrypt.check_password_hash(user.password, args['password']):

            return {
                'id': user.id,
                'token': generate_token(user)
            }

        return BAD_CREDENTIALS


class PasswordResetRequestAPI(restful.Resource):

    # TODO судя по всему необходим декоратор @auth_required
    def post(self):
        req_parser = reqparse.RequestParser()
        req_parser.add_argument('email', type=str, required=True)
        args = req_parser.parse_args()

        # TODO Не стоит формировать объекты запросов в контроллерах. Для этого
        #  стоит использовать репозиторий. Хотя в новой архитектуре это
        #  допускается.
        user = db.session.query(AppUser).filter(AppUser.email==args['email']).first()
        if user:
            # TODO Этот код и отправку почты можно разместить в службе
            #  (сценарии транзакции).
            password_reset = PasswordReset(user=user)
            db.session.add(password_reset)
            # TODO Не стоит управлять транзакцией внутри каждого обработчика
            #  запросов. Это приведет к дублированию кода. Эту функциональность
            #  можно вынести в декоратор либо в базовый класс контроллера
            #  запросов.
            db.session.commit()
            # TODO: Send the email using any preferred method

        return {}, 201  # TODO Необходимо использовать код успешного завершения
        #                  запроса по умолчанию централизованно, чтобы не
        #                  указывать его каждый раз. Код ответа можно поместить
        #                  в константы.


class PasswordResetConfirmAPI(restful.Resource):

    # TODO судя по всему необходим декоратор @auth_required
    def post(self):
        req_parser = reqparse.RequestParser()
        req_parser.add_argument('code', type=str, required=True)
        req_parser.add_argument('password', type=str, required=True)
        args = req_parser.parse_args()

        # TODO Этот сценарий можно разместить в службе (сценарии транзакции).

        # TODO Не стоит формировать объекты запросов в контроллерах. Для этого
        #  стоит использовать репозиторий. Хотя в новой архитектуре это
        #  допускается.
        password_reset = db.session.query(PasswordReset
                            ).filter(PasswordReset.code==args['code']
                            ).filter(PasswordReset.date>datetime.now()).first()

        if not password_reset:
            return CODE_NOT_VALID

        password_reset.user.set_password(args['password'])
        db.session.delete(password_reset)
        # TODO Не стоит управлять транзакцией внутри каждого обработчика
        #  запросов. Это приведет к дублированию кода. Эту функциональность
        #  можно вынести в декоратор либо в базовый класс контроллера
        #  запросов.
        db.session.commit()

        return {}, 200  # TODO Необходимо использовать код успешного завершения
        #                  запроса по умолчанию централизованно, чтобы не
        #                  указывать его каждый раз. Код ответа можно поместить
        #                  в константы.



class AdminOnlyAPI(restful.Resource):

    @admin_required
    def get(self):
        return {}, 200  # TODO Необходимо использовать код успешного завершения
        #                  запроса по умолчанию централизованно, чтобы не
        #                  указывать его каждый раз. Код ответа можно поместить
        #                  в константы.
