# TODO Перенести этот модуль в components/app/adapters/api/controllers/base.py

from flask.ext.restful import reqparse


class SignupLoginMixin(object):
    # TODO Лучше использовать базовый класс унаследованный от restful.Resource

    req_parser = reqparse.RequestParser()
    req_parser.add_argument('email', type=str, required=True)
    req_parser.add_argument('password', type=str, required=True)
